from typing import Dict, Any, List
import json
import yaml
import asyncio
import logging
import hashlib
from datetime import datetime
from app.core.agents.validation_agent import ValidationAgent
from app.core.agents.nlp_question_agent import NLPQuestionAgent
from app.core.processors.sonar_parser import SonarParser
from app.core.processors.zip_processor import ZipProcessor
from app.core.processors.chunk_splitter import ChunkSplitter
from app.core.llm.manager import LLMManager

logger = logging.getLogger(__name__)

class MasterAgent:
    """Orchestrates code review using multiple agents for validation, analysis, and scoring."""

    MODEL_TASK_MAPPING = {
        "validation": "mistral_large",
        "security": "mistral_large",
        "quality": "mistral_large",
        "performance": "claude3_7_sonnet",
        "scorecard": "claude3_7_sonnet"
    }

    def __init__(self, model_name: str, model_backend: str, tech_stack: List[str] = None):
        """Initialize MasterAgent with model, backend, and tech stack.

        Args:
            model_name (str): Name of the LLM model (e.g., 'parallel', 'mistral_large').
            model_backend (str): Backend for the LLM (e.g., 'bedrock').
            tech_stack (List[str], optional): List of tech stack languages (e.g., ['Python', 'JavaScript']).
        """
        self.model_name = model_name
        self.model_backend = model_backend
        self.tech_stack = tech_stack or []
        self.is_parallel = model_name.lower() == "parallel"
        self.task_cache = {}  # Cache task results

        available_models = self._get_available_models()
        if self.is_parallel:
            for task, model in self.MODEL_TASK_MAPPING.items():
                if model not in available_models:
                    logger.error(f"Model {model} for {task} not in config/models.yaml")
                    raise ValueError(f"Invalid model {model} for {task}")
        elif model_name not in available_models:
            logger.error(f"Model {model_name} not in config/models.yaml")
            raise ValueError(f"Invalid model {model_name}")

        try:
            with open("config/models.yaml", "r") as f:
                self.prompts = yaml.safe_load(f).get("prompts", {})
        except Exception as e:
            logger.error(f"Failed to load prompts: {str(e)}")
            self.prompts = {}

        validation_model = self.MODEL_TASK_MAPPING["validation"] if self.is_parallel else model_name
        scorecard_model = self.MODEL_TASK_MAPPING["scorecard"] if self.is_parallel else model_name
        self.validation_agent = ValidationAgent(
            tech_stack=self.tech_stack,
            model_name=validation_model,
            model_backend=model_backend
        )
        self.nlp_agent = NLPQuestionAgent(
            model_name=scorecard_model,
            model_backend=model_backend
        )
        self.parser = SonarParser()
        self.zip_processor = ZipProcessor(None)
        self.splitter = ChunkSplitter(chunk_size=200)

        if self.is_parallel:
            self.llms = {}
            for task, model_name in self.MODEL_TASK_MAPPING.items():
                if task in ["security", "quality", "performance"]:
                    try:
                        self.llms[task] = LLMManager(model_name, self.model_backend)
                    except Exception as e:
                        logger.warning(f"Failed to initialize {model_name} for {task}: {e}, falling back to mistral_large")
                        self.llms[task] = LLMManager("mistral_large", self.model_backend)
        else:
            self.llms = {
                task: LLMManager(self.model_name, self.model_backend)
                for task in ["security", "quality", "performance"]
            }

        logger.info(f"Initialized MasterAgent: mode={'parallel' if self.is_parallel else 'single'}, model_name={model_name}")

    def _get_available_models(self) -> List[str]:
        """Load available model names from config.

        Returns:
            List[str]: List of available model names.
        """
        try:
            with open("config/models.yaml", "r") as f:
                config = yaml.safe_load(f)
            return list(config["backends"][self.model_backend]["models"].keys())
        except Exception as e:
            logger.error(f"Failed to load models: {str(e)}")
            return []

    def _get_cache_key(self, task: str, data: Any) -> str:
        """Generate cache key for a task.

        Args:
            task (str): Task name (e.g., 'security').
            data (Any): Data to hash for the key.

        Returns:
            str: MD5 hash of task and data.
        """
        return hashlib.md5(f"{task}:{json.dumps(data, sort_keys=True)}".encode()).hexdigest()

    async def review_code(self, sonar_file: str, zip_path: str, spec_path: str, question_file: str = None) -> Dict[str, Any]:
        """Generate a code review report by orchestrating validation, analysis, and scoring.

        Args:
            sonar_file (str): Path to SonarQube report.
            zip_path (str): Path to source code zip.
            spec_path (str): Path to specification file.
            question_file (str, optional): Path to scorecard questions.

        Returns:
            Dict[str, Any]: Review report with screening, security, quality, performance, scorecard, and summary.
        """
        try:
            logger.debug(f"Starting review: zip_path={zip_path}")
            validation_result = await self._validate_submission(zip_path)
            if not validation_result["valid"]:
                return self._create_error_report(validation_result)

            sonar_data, doc_coverage = await self._process_sonar(sonar_file)
            code_chunks = await self._process_code(zip_path)

            # Parallel task execution
            tasks = [
                self._analyze_security(sonar_data, code_chunks),
                self._analyze_quality(sonar_data, code_chunks, doc_coverage),
                self._analyze_performance(sonar_data, code_chunks),
                self._process_scorecard(question_file, sonar_data, code_chunks, spec_path)
            ]
            security, quality, performance, scorecard = await asyncio.gather(*tasks, return_exceptions=True)

            results = self._compile_results(validation_result, security, quality, performance, scorecard, sonar_data, doc_coverage)
            results = self._calculate_scores(results)

            logger.info(f"Review completed: total_score={results['summary']['total']}, scorecard_score={results['summary']['scorecard']}, answered_questions={len([a for a in results['scorecard'] if a.get('answer') not in ['Evaluation not available', 'No valid answers generated', 'Evaluation failed']])}")
            with open("report.json", "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2)
            return results

        except Exception as e:
            logger.error(f"Review failed: {str(e)}")
            results = self._create_error_report({"valid": False, "reason": str(e), "languages": []})
            with open("report.json", "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2)
            return results

    async def _validate_submission(self, zip_path: str) -> Dict[str, Any]:
        """Validate the code submission.

        Args:
            zip_path (str): Path to source code zip.

        Returns:
            Dict[str, Any]: Validation result with valid status, reason, and languages.
        """
        return await self.validation_agent.validate_submission(zip_path)

    async def _process_sonar(self, sonar_file: str) -> tuple[Dict, float]:
        """Parse SonarQube report and extract documentation coverage.

        Args:
            sonar_file (str): Path to SonarQube report.

        Returns:
            tuple[Dict, float]: SonarQube data and documentation coverage percentage.
        """
        sonar_data = self.parser.parse(sonar_file)
        doc_coverage = self.parser.get_doc_coverage()
        logger.debug(f"Sonar data: {len(sonar_data['issues'])} issues, doc_coverage: {doc_coverage}")
        return sonar_data, doc_coverage

    async def _process_code(self, zip_path: str) -> List[Dict]:
        """Extract and chunk code from zip file.

        Args:
            zip_path (str): Path to source code zip.

        Returns:
            List[Dict]: List of code chunks with path and content.
        """
        self.zip_processor.zip_path = zip_path
        code_data = self.zip_processor.extract(zip_path)
        code_chunks = []
        for file in code_data["files"]:
            chunks = self.splitter.split(file["content"])
            code_chunks.extend([{"path": file["path"], "content": chunk} for chunk in chunks])
        return code_chunks[:5]  # Increased from 3

    async def _analyze_security(self, sonar_data: Dict, code_chunks: List[Dict]) -> List[Dict]:
        """Analyze security issues using LLM.

        Args:
            sonar_data (Dict): SonarQube report data.
            code_chunks (List[Dict]): List of code chunks.

        Returns:
            List[Dict]: List of security findings.
        """
        cache_key = self._get_cache_key("security", {"sonar_data": sonar_data, "code_chunks": code_chunks})
        if cache_key in self.task_cache:
            logger.debug("Cache hit for security")
            return self.task_cache[cache_key]

        messages = [
            {
                "role": "system",
                "content": self.prompts.get("security", {}).get("system", "") + "\nReturn a JSON array of issues: [{'issue': str, 'type': str, 'severity': str, 'confidence': int, 'file': str, 'recommendation': str}]. No extra text or markdown."
            },
            {
                "role": "user",
                "content": self.prompts.get("security", {}).get("user", "").format(
                    sonar_data=json.dumps(sonar_data, indent=2)[:1000],  # Increased from 300
                    code_samples=json.dumps(code_chunks, indent=2)[:2000]  # Increased from 500
                )
            }
        ]
        try:
            logger.debug(f"Using model {self.llms['security'].model_name} for security: prompt={json.dumps(messages)[:200]}...")
            response = await self.llms["security"].generate(messages)
            logger.debug(f"Security response: {response[:200]}...")
            parsed = json.loads(response) if response else []
            if not isinstance(parsed, list):
                logger.warning(f"Expected array for security, got: {response[:100]}")
                return []
            self.task_cache[cache_key] = parsed
            return parsed
        except json.JSONDecodeError as e:
            logger.error(f"Security JSON parsing failed: {str(e)}, response={response[:200]}")
            return []
        except Exception as e:
            logger.error(f"Security analysis failed: {str(e)}")
            return []

    async def _analyze_quality(self, sonar_data: Dict, code_chunks: List[Dict], doc_coverage: float) -> Dict:
        """Analyze code quality using LLM.

        Args:
            sonar_data (Dict): SonarQube report data.
            code_chunks (List[Dict]): List of code chunks.
            doc_coverage (float): Documentation coverage percentage.

        Returns:
            Dict: Quality metrics with maintainability score, code smells, and doc coverage.
        """
        cache_key = self._get_cache_key("quality", {"sonar_data": sonar_data, "code_chunks": code_chunks})
        if cache_key in self.task_cache:
            logger.debug("Cache hit for quality")
            return self.task_cache[cache_key]

        messages = [
            {
                "role": "system",
                "content": self.prompts.get("quality", {}).get("system", "") + "\nReturn a JSON object: {'maintainability_score': int, 'code_smells': int, 'doc_coverage': float}. No extra text or markdown. Assign maintainability_score 80-100 for well-structured code unless clear issues exist."
            },
            {
                "role": "user",
                "content": self.prompts.get("quality", {}).get("user", "").format(
                    sonar_data=json.dumps(sonar_data, indent=2)[:1000],  # Increased from 300
                    code_samples=json.dumps(code_chunks, indent=2)[:2000]  # Increased from 500
                )
            }
        ]
        try:
            logger.debug(f"Using model {self.llms['quality'].model_name} for quality: prompt={json.dumps(messages)[:200]}...")
            response = await self.llms["quality"].generate(messages)
            logger.debug(f"Quality response: {response[:200]}...")
            parsed = json.loads(response) if response else {}
            if not isinstance(parsed, dict):
                logger.warning(f"Expected object for quality, got: {response[:100]}")
                return {"maintainability_score": 50, "code_smells": len(sonar_data["issues"]), "doc_coverage": doc_coverage}
            parsed = {
                "maintainability_score": parsed.get("maintainability_score", 50),
                "code_smells": parsed.get("code_smells", len(sonar_data["issues"])),
                "doc_coverage": parsed.get("doc_coverage", doc_coverage)
            }
            self.task_cache[cache_key] = parsed
            return parsed
        except json.JSONDecodeError as e:
            logger.error(f"Quality JSON parsing failed: {str(e)}, response={response[:200]}")
            return {"maintainability_score": 50, "code_smells": len(sonar_data["issues"]), "doc_coverage": doc_coverage}
        except Exception as e:
            logger.error(f"Quality analysis failed: {str(e)}")
            return {"maintainability_score": 50, "code_smells": len(sonar_data["issues"]), "doc_coverage": doc_coverage}

    async def _analyze_performance(self, sonar_data: Dict, code_chunks: List[Dict]) -> Dict:
        """Analyze performance using LLM.

        Args:
            sonar_data (Dict): SonarQube report data.
            code_chunks (List[Dict]): List of code chunks.

        Returns:
            Dict: Performance metrics with rating, bottlenecks, and suggestions.
        """
        cache_key = self._get_cache_key("performance", {"sonar_data": sonar_data, "code_chunks": code_chunks})
        if cache_key in self.task_cache:
            logger.debug("Cache hit for performance")
            return self.task_cache[cache_key]

        messages = [
            {
                "role": "system",
                "content": self.prompts.get("performance", {}).get("system", "") + "\nReturn a JSON object: {'rating': int, 'bottlenecks': [str], 'optimization_suggestions': [str]}. No extra text or markdown. Assign rating 80-100 for efficient code unless clear bottlenecks exist."
            },
            {
                "role": "user",
                "content": self.prompts.get("performance", {}).get("user", "").format(
                    sonar_data=json.dumps(sonar_data, indent=2)[:1000],  # Increased from 300
                    code_samples=json.dumps(code_chunks, indent=2)[:2000]  # Increased from 500
                )
            }
        ]
        try:
            logger.debug(f"Using model {self.llms['performance'].model_name} for performance: prompt={json.dumps(messages)[:200]}...")
            response = await self.llms["performance"].generate(messages)
            logger.debug(f"Performance response: {response[:200]}...")
            parsed = json.loads(response) if response else {}
            if not isinstance(parsed, dict):
                logger.warning(f"Expected object for performance, got: {response[:100]}")
                return {"rating": 60, "bottlenecks": [], "optimization_suggestions": []}
            parsed = {
                "rating": parsed.get("rating", 60),
                "bottlenecks": parsed.get("bottlenecks", []),
                "optimization_suggestions": parsed.get("optimization_suggestions", [])
            }
            self.task_cache[cache_key] = parsed
            return parsed
        except json.JSONDecodeError as e:
            logger.error(f"Performance JSON parsing failed: {str(e)}, response={response[:200]}")
            return {"rating": 60, "bottlenecks": [], "optimization_suggestions": []}
        except Exception as e:
            logger.error(f"Performance analysis failed: {str(e)}")
            return {"rating": 60, "bottlenecks": [], "optimization_suggestions": []}

    async def _process_scorecard(self, question_file: str, sonar_data: Dict, code_chunks: List[Dict], spec_path: str) -> List[Dict]:
        """Process scorecard questions using NLP agent.

        Args:
            question_file (str): Path to JSON file with questions.
            sonar_data (Dict): SonarQube report data.
            code_chunks (List[Dict]): List of code chunks.
            spec_path (str): Path to specification file.

        Returns:
            List[Dict]: List of scorecard answers.
        """
        if not question_file:
            return []
        try:
            with open(spec_path, "r", encoding="utf-8") as f:
                spec = f.read()
            scorecard = await self.nlp_agent.process_questions(question_file, sonar_data, code_chunks, spec)
            logger.info(f"Processed {len(scorecard)} scorecard answers")
            if not any(a.get("answer") not in ["Evaluation not available", "No valid answers generated", "Evaluation failed"] for a in scorecard):
                logger.warning("No valid scorecard answers with claude3_7_sonnet, retrying with mistral_large")
                self.nlp_agent = NLPQuestionAgent(model_name="mistral_large", model_backend=self.model_backend)
                scorecard = await self.nlp_agent.process_questions(question_file, sonar_data, code_chunks, spec)
            return scorecard
        except Exception as e:
            logger.error(f"Scorecard failed: {str(e)}")
            return [{"question": "Unknown", "category": "", "answer": f"Scorecard failed: {str(e)}", "confidence": 1, "weight": 0}]

    def _compile_results(self, validation_result: Dict, security: Any, quality: Any, performance: Any, scorecard: Any, sonar_data: Dict, doc_coverage: float) -> Dict:
        """Compile analysis results into a report.

        Args:
            validation_result (Dict): Validation result.
            security (Any): Security findings.
            quality (Any): Quality metrics.
            performance (Any): Performance metrics.
            scorecard (Any): Scorecard answers.
            sonar_data (Dict): SonarQube report data.
            doc_coverage (float): Documentation coverage percentage.

        Returns:
            Dict: Compiled review report.
        """
        return {
            "screening_result": validation_result,
            "security_findings": security if isinstance(security, list) else [],
            "quality_metrics": quality if isinstance(quality, dict) else {"maintainability_score": 50, "code_smells": len(sonar_data["issues"]), "doc_coverage": doc_coverage},
            "performance_metrics": performance if isinstance(performance, dict) else {"rating": 60, "bottlenecks": [], "optimization_suggestions": []},
            "scorecard": scorecard if isinstance(scorecard, list) else [],
            "summary": {"code_quality": 50, "security": 100, "performance": 60, "scorecard": 0, "total": 0.0},
            "timestamp": datetime.now().isoformat()
        }

    def _calculate_scores(self, results: Dict) -> Dict:
        """Calculate summary scores for the review report.

        Args:
            results (Dict): Compiled review report.

        Returns:
            Dict: Updated report with calculated scores.
        """
        quality_score = min(results["quality_metrics"].get("maintainability_score", 50), 100)
        security_score = 100 - (len(results["security_findings"]) * 15)
        security_score = max(min(security_score, 100), 0)
        performance_score = min(results["performance_metrics"].get("rating", 60), 100)
        results["quality_metrics"]["code_smells"] = results["quality_metrics"].get("code_smells", 0)

        scorecard_answers = [
            a for a in results["scorecard"]
            if a.get("answer") not in ["Evaluation not available", "No valid answers generated", "Evaluation failed"]
        ]
        scorecard_score = 0
        if scorecard_answers:
            sum_conf_weight = sum(a["confidence"] * a["weight"] for a in scorecard_answers if "confidence" in a and "weight" in a)
            sum_weight = sum(a["weight"] for a in scorecard_answers if "weight" in a)
            scorecard_score = (sum_conf_weight / sum_weight) * (100 / 5) if sum_weight > 0 else 0
            scorecard_score = max(min(scorecard_score, 100), 0)

        results["summary"] = {
            "code_quality": quality_score,
            "security": security_score,
            "performance": performance_score,
            "scorecard": round(scorecard_score, 1),
            "total": round(
                quality_score * 0.35 +
                security_score * 0.25 +
                performance_score * 0.2 +
                scorecard_score * 0.2, 1
            )
        }
        return results

    def _create_error_report(self, validation_result: Dict) -> Dict:
        """Create an error report for failed reviews.

        Args:
            validation_result (Dict): Validation result with reason for failure.

        Returns:
            Dict: Error report with default values.
        """
        return {
            "screening_result": validation_result,
            "security_findings": [],
            "quality_metrics": {"maintainability_score": 0, "code_smells": 0, "doc_coverage": 0},
            "performance_metrics": {"rating": 0, "bottlenecks": [], "optimization_suggestions": []},
            "scorecard": [],
            "summary": {"code_quality": 0, "security": 0, "performance": 0, "scorecard": 0, "total": 0.0},
            "timestamp": datetime.now().isoformat()
        }